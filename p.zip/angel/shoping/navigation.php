<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Insert title here</title>
</head>
<body>
<?php
?>
	<div align="center">
		<nav>
		<a href="index.php" >Home</a>|
			<a href="index.html">About US</a>| 
			<a href="login.php">login</a>|		
			<a href="registration.php">Registration</a>
			<input type="text" name="search"> <input type="submit"
				name="search" value="search">

			</form>
		</nav>
	</div>
</body>
</html>

