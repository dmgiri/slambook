<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Insert title here</title>
</head>
<body>
<?php
?>
	<div align="center">
		<nav>
			<a href="index.php">Home</a>| <a href="index.html">About US</a>| <a
				href="login.php">login</a>| <a href="registration.php">Registration</a>
			<form action="product.php" method="get">
				<input type="text" name="se" /> <input type="submit" value="search">
			</form>|
			<a href="product.php">Product List</a>
		</nav>
	</div>
</body>
</html>

