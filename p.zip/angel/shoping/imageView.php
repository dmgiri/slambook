<?php
	$conn = mysql_connect("localhost", "root", "root");
    mysql_select_db("db") or die(mysql_error());
    if(isset($_GET['1'])) {
        $sql = "SELECT product_id,image FROM product WHERE imageId=" . $_GET['image_id'];
		$result = mysql_query("$sql") or die("<b>Error:</b> Problem on Retrieving Image BLOB<br/>" . mysql_error());
		$row = mysql_fetch_array($result);
		header("Content-type: image/jpeg");
        echo $row["image"];
	}
	mysql_close($conn);
?>