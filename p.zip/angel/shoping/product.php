<?php
require 'navigation.php';
$con = mysqli_connect( "localhost", "root", "root" );
mysqli_select_db( $con, "D_D" );

$sql = "SELECT product_id FROM product ORDER BY imageId DESC";
$result = mysql_query($sql);
?>
<HTML>
<HEAD>
<TITLE>List BLOB Images</TITLE>
<link href="imageStyles.css" rel="stylesheet" type="text/css" />
</HEAD>
<BODY>
<?php
while($row = mysql_fetch_array($result)) {
	?>
		<img src="imageView.php?image_id=<?php echo $row["image"]; ?>" /><br/>
	
<?php		
	}
    mysql_close($conn);
?>
</BODY>
</HTML>