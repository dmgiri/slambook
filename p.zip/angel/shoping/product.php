<?php
require_once 'navigation.php';
$con = mysqli_connect( "localhost", "root", "root" );
mysqli_select_db( $con, "D_D" );
$sql = "select * from product where product_name like '".$_REQUEST['se']."%';";
$result = mysqli_query($con,$sql);


?>
<html>
<head>
	<title>Product Details</title>
	<link rel="stylesheet" href="css/product.css">
</head>

<?php
while($row = mysqli_fetch_array($result)) {
	echo $row['0'];
	echo '<img src="data:image/jpeg;base64,'.base64_encode( $row['3'] ).'"/>';
	?>
<?php		
	}
    mysqli_close($con);
?>
</BODY>
</HTML>